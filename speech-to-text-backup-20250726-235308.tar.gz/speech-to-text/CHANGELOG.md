# Speech to Text Changelog

## [Initial Version] - 2025-03-19
